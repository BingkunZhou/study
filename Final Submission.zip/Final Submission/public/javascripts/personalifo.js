function send() {//personalifo.html



//save data to sql

            var Name_of_people = document.getElementById("Name_of_people").value;
            var Email = document.getElementById("Email").value;
            var Phone = document.getElementById("Phone").value;
            var Other_information = document.getElementById("Other_information").value;
            var Position = document.getElementById("Position").value;

 if(Position == "User" || Position == "Manager"){


  //document.getElementById("check_position").innerHTML = " The position is correct";


           var xhttpsql = new XMLHttpRequest();
            xhttpsql.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("check_sql").innerText = this.responseText;
                }
            };

            xhttpsql.open("POST", "/add_personalifo_sql", true);
            xhttpsql.setRequestHeader("Content-type", "application/json");

           xhttpsql.send(JSON.stringify({ Name_of_people:Name_of_people,Email:Email,Phone:Phone,Other_information:Other_information,Position:Position}));



//return the massage to html

            var xhttp1 = new XMLHttpRequest();
            xhttp1.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("Name_output").innerText = this.responseText;
                }
            };

            xhttp1.open("POST", "/show_Name_output", true);
            xhttp1.setRequestHeader("Content-type", "application/json");

           xhttp1.send(JSON.stringify({ Name_of_people: Name_of_people}));



             var xhttp2 = new XMLHttpRequest();
            xhttp2.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("Email_output").innerText = this.responseText;
                }
            };

            xhttp2.open("POST", "/show_Email_output", true);
            xhttp2.setRequestHeader("Content-type", "application/json");

           xhttp2.send(JSON.stringify({ Email: Email}));


            var xhttp3 = new XMLHttpRequest();
            xhttp3.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("Phone_output").innerText = this.responseText;
                }
            };

            xhttp3.open("POST", "/show_Phone_output", true);
            xhttp3.setRequestHeader("Content-type", "application/json");

           xhttp3.send(JSON.stringify({ Phone: Phone}));


            var xhttp4 = new XMLHttpRequest();
            xhttp4.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("Other_information_output").innerText = this.responseText;
                }
            };

            xhttp4.open("POST", "/show_Other_information_output", true);
            xhttp4.setRequestHeader("Content-type", "application/json");

           xhttp4.send(JSON.stringify({ Other_information: Other_information}));


           var xhttp5 = new XMLHttpRequest();
            xhttp5.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("Position_output").innerText = this.responseText;
                }
            };

            xhttp5.open("POST", "/show_Position_output", true);
            xhttp5.setRequestHeader("Content-type", "application/json");

           xhttp5.send(JSON.stringify({ Position: Position}));





}else{
document.getElementById("check_position").innerHTML = "The position is incorrect, try User or Manager. Note: you need login first!";
}

}