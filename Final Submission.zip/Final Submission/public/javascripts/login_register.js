
//register.html
function SubmitNewAccount() {


            var Account = document.getElementById("Account").value;
            var Password = document.getElementById("Password").value;


            var xhttp_Account = new XMLHttpRequest();
            xhttp_Account.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("Account_output").innerText = this.responseText;
                }
            };

            xhttp_Account.open("POST", "/show_Account_output", true);
            xhttp_Account.setRequestHeader("Content-type", "application/json");

           xhttp_Account.send(JSON.stringify({ Account: Account}));



             var xhttp_Password = new XMLHttpRequest();
            xhttp_Password.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("Password_output").innerText = this.responseText;
                }
            };

            xhttp_Password.open("POST", "/show_Password_output", true);
            xhttp_Password.setRequestHeader("Content-type", "application/json");

           xhttp_Password.send(JSON.stringify({ Password: Password}));


             var xhttp_register = new XMLHttpRequest();
            xhttp_register.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("register_output").innerText = this.responseText;
                }

            };

            xhttp_register.open("POST", "/register", true);
            xhttp_register.setRequestHeader("Content-type", "application/json");

           xhttp_register.send(JSON.stringify({ Account:Account,Password:Password}));










}

function login() {


           var Account = document.getElementById("Account").value;
            var Password = document.getElementById("Password").value;


            var xhttp_Account = new XMLHttpRequest();
            xhttp_Account.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("Login_output").innerText = this.responseText;
                }
            };

            xhttp_Account.open("POST", "/LoginOk", true);
            xhttp_Account.setRequestHeader("Content-type", "application/json");

           xhttp_Account.send(JSON.stringify({ Account:Account,Password:Password}));
}