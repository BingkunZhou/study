//add new row method by script addtasks.html
function addrow()
{


    var Id = document.getElementById("Id").value;
    var Number_of_Group_member = document.getElementById("Number_of_Group_member").value;
    var Name_of_Group_member = document.getElementById("Name_of_Group_member").value;
    var Work_content = document.getElementById("Work_content").value;
    var Start_Time = document.getElementById("Start_Time").value;
    var End_Time = document.getElementById("End_Time").value;
    var Manager = document.getElementById("Manager").value;





/*send data to sql*/
    var xhttp_submitsql = new XMLHttpRequest();

    xhttp_submitsql.onreadystatechange = function() {
document.getElementById("check_login").innerText = this.responseText;
    };

    xhttp_submitsql.open("POST", "/submit_data_to_sql", true);
    xhttp_submitsql.setRequestHeader("Content-type", "application/json");
    xhttp_submitsql.send(JSON.stringify({Id: Id, Number_of_Group_member: Number_of_Group_member, Name_of_Group_member: Name_of_Group_member, Work_content: Work_content, Start_Time: Start_Time, End_Time: End_Time, Manager: Manager}));

}
/*show data*/
function showrow()
{
    var xhr;
    var Id = document.getElementById("Id").value;
    var Number_of_Group_member = document.getElementById("Number_of_Group_member").value;
    var Name_of_Group_member = document.getElementById("Name_of_Group_member").value;
    var Work_content = document.getElementById("Work_content").value;
    var Start_Time = document.getElementById("Start_Time").value;
    var End_Time = document.getElementById("End_Time").value;
    var Manager = document.getElementById("Manager").value;

    var mytable = document.getElementById("mytable");

     if(window.XMLHttpRequest){
            xhr=new XMLHttpRequest();
        }else{
            xhr=new ActiveXObject("Microsoft","XMLHTTP");
        }

    xhr.open("POST","/showtasks",true);
    xhr.setRequestHeader("content-type","application/x-www-form-urlencoded");

 xhr.onreadystatechange=function(){

//document.getElementById("check_login").innerText = this.responseText;

 mytable.innerHTML="<tr><th id ='Id_head'='>id</th><th id ='Number_of_Group_member_head'>Number of Group member:</th><th id ='Name_of_Group_member_head'>Name of Group member:</th><th id ='Events_head'>Events</th><th id ='StartTime_head'>Start Time</th><th id ='EndTime_head'>End Time</th><th id ='Manager_head'>Manager</th></tr>";

     if(xhr.readyState==4&&xhr.status==200){
//                console.log(xhr.responseText);
                var datalist=JSON.parse(xhr.responseText);
                for(var i=0;i<datalist.length;i++){
                    console.log(datalist[i].Task_Id);
                    console.log(datalist[i].Number_of_Group_member);
                    console.log(datalist[i].Name_of_Group_member);
                    console.log(datalist[i].Work_content);
                    console.log(datalist[i].Start_Time);
                    console.log(datalist[i].End_Time);
                    console.log(datalist[i].Manager);
                    mytable.innerHTML=mytable.innerHTML+"<tr><td>"
                    +datalist[i].Task_Id+"</td><td>"
                    +datalist[i].Number_of_Group_member+"</td><td>"
                    +datalist[i].Name_of_Group_member+"</td><td>"
                    +datalist[i].Work_content+"</td><td>"
                    +datalist[i].Start_Time+"</td><td>"
                    +datalist[i].End_Time+"</td><td>"
                    +datalist[i].Manager+"</td><td>";
                }
            }

 };

xhr.send();


}


function Delete() {
 var delete_Id = document.getElementById("delete_Id").value;

    var Id = document.getElementById("Id").value;
    var Number_of_Group_member = document.getElementById("Number_of_Group_member").value;
    var Name_of_Group_member = document.getElementById("Name_of_Group_member").value;
    var Work_content = document.getElementById("Work_content").value;
    var Start_Time = document.getElementById("Start_Time").value;
    var End_Time = document.getElementById("End_Time").value;
    var Manager = document.getElementById("Manager").value;





/*send data to sql*/
    var xhttp_deletesql = new XMLHttpRequest();

    xhttp_deletesql.onreadystatechange = function() {
document.getElementById("check_login").innerText = this.responseText;
    };

    xhttp_deletesql.open("POST", "/deletetasks", true);
    xhttp_deletesql.setRequestHeader("Content-type", "application/json");
    xhttp_deletesql.send(JSON.stringify({delete_Id: delete_Id, Id: Id, Number_of_Group_member: Number_of_Group_member, Name_of_Group_member: Name_of_Group_member, Work_content: Work_content, Start_Time: Start_Time, End_Time: End_Time, Manager: Manager}));

}
