

//show time
var dt = new Date();
document.getElementById("datetime").innerHTML = dt.toLocaleString();


/* AJAX Logout */
function logout(){

    console.log("Logout");

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
        if (this.readyState == 2 && this.status == 200) {

            // Logout Successful, redirect to home
            window.location.pathname = "/";

        }
    };

    xhttp.open("POST", "/logout", true);
    xhttp.send();

}