var express = require('express');
var router = express.Router();
/*var argon2 = require('argon2');*/

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

/*
router.post('/register',async function(req, res,next){
Account=req.body.Account;
password=req.body.Password;
var phash = null;

try {
    phash = await argon2.hash(req.body.Password;);
  } catch (err) {
    res.sendStatus(500);
    return;
  }
var query = "INSERT INTO account (Account,Password,phash) VALUES (?,?,?)";
connection.query(query, [Account,password,phash], function(err){

if(err){
console.log("Error to add a new account to sql")
res.sendStatus(500);
return;
}

console.log("successful to add a new account to sql")
req.send();
});



});

router.post('/LoginOk', function(req, res,next){


var Account = req.body.Account;
var Password = req.body.Password;


    //Connect to the database
    req.pool.getConnection( function(err,connection) {
        if (err) { throw err;}

        // Query to get user info
        var query = "SELECT Account,session_id,pwordhash,pwordsalt FROM account WHERE Account=?";
        connection.query(query, [Account], function(err, users){
            if (err || users.length <= 0) {
                // No valid user found
                res.status(401).send();
                return;
            }

            // Hash and salt Password
            var hash = crypto.createHash('sha256');
            hash.update(Password+users[0].pwordsalt);
            var submittedhash = hash.digest('hex');
            console.log(submittedhash);

            // Check if salted hashes match
            if(users[0].pwordhash===submittedhash){
                // Correct Password, store session
                var query = "UPDATE users SET session_id = ? WHERE Account = ?";
                connection.query(query, [req.session.Account,users[0].Account]);
                res.send();
            } else {
                // Wrong Password
                res.status(401).send();
            }
        });
    });



});

*/



module.exports = router;
