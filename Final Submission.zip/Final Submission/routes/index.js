var express = require('express');
var router = express.Router();
var argon2 = require('argon2');
const crypto = require('crypto');
/* GET home page. */

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});




/*addtasks1.html*/


router.post('/submit_data_to_sql', function(req, res,next){

var Id_text = req.body.Id;
var Number_of_Group_member_text = req.body.Number_of_Group_member;
var Name_of_Group_member_text = req.body.Name_of_Group_member;
var Work_content_text = req.body.Work_content;
var Start_Time_text = req.body.Start_Time;
var End_Time_text = req.body.End_Time;
var Manager_text = req.body.Manager;


 //Connect to the database to save the data
    req.pool.getConnection( function(err,connection) {
        if (err) { throw err;}

// Query to check if user logged in
        var query = "SELECT id FROM account WHERE session_id=?";
        connection.query(query, [req.session.id], function(err, account){
            if (err || account.length <= 0) {
                // Not logged in
                res.send('You need login first!');
                res.status(401).send();
                return;
            }


//var query ="select Task_Id from tasks where Task_Id =? ";
//connection.query(query,[Id_text], function(err,tasks){
//if(tasks[0].Task_Id===Id_text){
//res.send('This task id has already been used!');
               // res.status(405).send();
//return;

//}


   // Add post to DB
        var query = "INSERT INTO tasks (Task_Id,Number_of_Group_member,Name_of_Group_member,Work_content,Start_Time,End_Time,Manager) VALUES (?,?,?,?,?,?,?)";
         connection.query(query, [Id_text,Number_of_Group_member_text,Name_of_Group_member_text,Work_content_text,Start_Time_text,End_Time_text,Manager_text], function(err){
                if (err) {
                    // Error
                    res.status(405).send();
                } else {
                    // OK
                    res.send();
                }
            });


//});
});

});
});

router.post('/showtasks', function(req, res,next){

    req.pool.getConnection( function(err,connection) {
        if (err) { throw err;}

        // Query to check if user logged in
        var query = "SELECT id FROM account WHERE session_id=?";
        connection.query(query, [req.session.id], function(err, account){
            if (err || account.length <= 0) {
                // Not logged in
                 res.send('You need login first!');
                res.status(401).send();
                return;
            }


           let query ="select Task_Id,Number_of_Group_member,Name_of_Group_member,Work_content,Start_Time,End_Time,Manager from tasks ";

    connection.query(query,function(err,data){

             if(err===null||err==undefined){

                 res.send(data);

                 console.log(typeof data);
             }
          });
});

});
});

/*delete the row*/
router.post('/deletetasks', function(req, res,next){

var delete_Id_text = req.body.delete_Id;



    req.pool.getConnection( function(err,connection) {
        if (err) { throw err;}

        // Query to check if user logged in
        var query = "SELECT id FROM account WHERE session_id=?";
        connection.query(query, [req.session.id], function(err, account){
            if (err || account.length <= 0) {
                // Not logged in
                res.send('You need login first!');
                res.status(401).send();
                return;
            }

  //var query = "DELETE FROM tasks WHERE Task_Id = delete_Id_text";
  var query = "DELETE FROM tasks WHERE Task_Id = ?";
          connection.query(query, [delete_Id_text], function(err){
                if (err) {
                    res.send('fail to delete the row!');
                    res.status(405).send();
                } else {
                    // OK
                    res.send('delete the row success!');
                }
            });

});

});
});









/* get personal information link to personalifo.html*/

router.post('/add_personalifo_sql', function(req, res,next){

var Name_of_people_text = req.body.Name_of_people;
var Email_text = req.body.Email;
var Phone_text = req.body.Phone;
var Other_information_text = req.body.Other_information;
var position_text = req.body.Position;


 //Connect to the database to save the data
    req.pool.getConnection( function(err,connection) {
        if (err) { throw err;}

         // Query to check if user logged in
        var query = "SELECT id FROM account WHERE session_id=?";
        connection.query(query, [req.session.id], function(err, account){
            if (err || account.length <= 0) {
                // Not logged in
                 res.send('You need login first!');
                res.status(401).send();
                return;
            }


   // Add post to DB
        var query = "INSERT INTO personal_information (Name_of_people,Email,Phone,Other_information,position) VALUES (?,?,?,?,?)";
         connection.query(query, [Name_of_people_text,Email_text,Phone_text,Other_information_text,position_text], function(err){
                if (err) {
                    res.send('fail to add to the sql!');
                    res.status(405).send();
                } else {
                    // OK
                    res.send('New datas are add to the sql!');
                }
            });


});

});
});





router.post('/show_Name_output', function(req, res,next){
var Name_output = '';


var Name_of_people_text = req.body.Name_of_people;


Name_output = Name_of_people_text+"\n";

res.send(Name_output);

});


router.post('/show_Email_output', function(req, res,next){
var Email_output = '';


var Email_text = req.body.Email;


Email_output = Email_text+"\n";

res.send(Email_output);

});


router.post('/show_Phone_output', function(req, res,next){
var Phone_output = '';


var Phone_text = req.body.Phone;


Phone_output = Phone_text+"\n";

res.send(Phone_output);

});


router.post('/show_Other_information_output', function(req, res,next){
var Other_information_output = '';


var Other_information_text = req.body.Other_information;


Other_information_output = Other_information_text+"\n";

res.send(Other_information_output);

});



router.post('/show_Position_output', function(req, res,next){

var Position_output = '';


var Position_text = req.body.Position;


Position_output = Position_text+"\n";

res.send(Position_output);
});


/* get information link to register.html*/

router.post('/show_Account_output', function(req, res,next){
var Account_output = '';


var Account_text = req.body.Account;


Account_output = Account_text+"\n";

res.send(Account_output);

});


router.post('/show_Password_output', function(req, res,next){
var Password_output = '';


var Password_text = req.body.Password;


Password_output = Password_text+"\n";

res.send(Password_output);

});



router.post('/register',async function(req, res,next){
var Account_text=req.body.Account;
var Password_text=req.body.Password;

 var phash = null;
  try {
    phash = await argon2.hash(req.body.Password);
  } catch (err) {
    res.send('fail to add datas to the sql!');
    res.sendStatus(500);
    return;
  }

 //Connect to the database to save the data
    req.pool.getConnection( function(err,connection) {
        if (err) { throw err;}

   // Add post to DB
        var query = "INSERT INTO account (Account,id,pwordhash) VALUES (?,?,?)";
         connection.query(query, [Account_text,Account_text,phash], function(err){

                if (err) {
                    // Error
res.send('fail to add datas to the sql!');
                    res.status(401).send();


                } else {

                   // OK
                    res.send('New account is add to the sql!');
                }
            });


});






});



router.post('/LoginOk',async function(req, res,next){


var Account_text = req.body.Account;
var Password_text = req.body.Password;


 //Connect to the database
    req.pool.getConnection( function(err,connection) {
        if (err) { throw err;}

        // Query to get user info
        var query = "SELECT id,session_id,Account,pwordhash FROM account WHERE Account=?";
        //var query = "SELECT Account,pwordhash FROM account WHERE Account=?";
        connection.query(query, [Account_text],async function(err, account){
            if (err || account.length <= 0) {
                // No valid user found
                res.send('Account not found, account or password are not correct, just try Account = Account01; Password = Password01');
                res.status(401).send();
                return;
            }
 // Check
              try {
    if (await argon2.verify(account[0].pwordhash,Password_text)) {
              // Correct password, store session
               var query = "UPDATE account SET session_id = ? WHERE id = ?";
                connection.query(query, [req.session.id,account[0].id]);
                res.send('Account and password are correct');
            } else {
                 res.send('Account or password are not correct, just try Account = Account01; Password = Password01');
                res.status(401).send();
                return;
            }
              } catch (err) {
    // internal failure
    res.sendStatus(500);
    console.log(err)
    return;
  }



 });
 });

});


/* Logout. */
router.post('/logout', function(req, res, next) {

    //Connect to the database
    req.pool.getConnection( function(err,connection) {
        if (err) { throw err;}

        var query = "UPDATE account SET session_id = NULL WHERE session_id = ?";
        connection.query(query, [req.session.id], function(err){
            if (err) {
                res.status(403).send();
            } else {
                res.send();
            }
        });

    });

});





module.exports = router;