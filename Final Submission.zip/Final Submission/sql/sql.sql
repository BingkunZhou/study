PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE tasks (
    id VARCHAR(20) NOT NULL,
    Task_Id INT NOT NULL,
    Number_of_Group_member INT,
    Name_of_Group_member varchar(100),
    Work_content varchar(100),
    Start_Time DATE,
    End_Time DATE,
    Manager varchar(100),
    PRIMARY KEY (id)
    FOREIGN KEY (Account) REFERENCES account(id)
    );


    CREATE TABLE personal_information (
    id VARCHAR(20) NOT NULL,
    Account varchar(100),
    Name_of_people varchar(100),
    Email varchar(100),
    Phone varchar(100),
    Other_information varchar(200),
    position varchar(50),
    PRIMARY KEY (id),
    FOREIGN KEY (Account) REFERENCES account(id)

    );


    CREATE TABLE account (

    Account varchar(20) NOT NULL,,
    Password varchar(20) NOT NULL,,
    session_id VARCHAR(100) DEFAULT NULL,
    pwordhash VARCHAR(100) NOT NULL,
    pwordsalt VARCHAR(100) NOT NULL,
    PRIMARY KEY (id)
    );



INSERT INTO personal_information VALUES('Account1','Name1','Email1','Phone1','nothing');

INSERT INTO tasks VALUES(101,1,'people1','awdawdasas','2020-01-01','2020-02-02','m1');